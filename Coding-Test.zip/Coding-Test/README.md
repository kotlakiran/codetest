

findUniqueUsers : curl --location --request GET 'http://localhost:8080/users/findUniqueUsers'
updateUser : curl --location --request PUT 'http://localhost:8080/users/updateUser' \
--header 'Accept: application/json' \
--header 'Content-Type: application/json' \
--data-raw '{

}'

RUN Test:
mvn test