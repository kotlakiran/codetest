package com.siriuscom.codingtest.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.siriuscom.codingtest.dto.User;
import com.siriuscom.codingtest.dto.Users;

public interface UserService {

  public Users getUniqueUsers();
  public List<User> updateUsers(User user);

}
