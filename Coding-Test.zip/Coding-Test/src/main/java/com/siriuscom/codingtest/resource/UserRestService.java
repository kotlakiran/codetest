package com.siriuscom.codingtest.resource;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.siriuscom.codingtest.dto.User;
import com.siriuscom.codingtest.dto.Users;

@RestController
@RequestMapping("users")
public interface UserRestService {

  @GetMapping(value="/findUniqueUsers", produces = "application/json")
  public Users getUniqueUsers();
  @PutMapping (
      value = "/updateUser", consumes = "application/json", produces = "application/json")
  public List<User> updateUsers(User user);
}
