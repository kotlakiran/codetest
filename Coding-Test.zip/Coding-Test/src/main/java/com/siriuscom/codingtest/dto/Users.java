package com.siriuscom.codingtest.dto;

import java.util.List;
import java.util.Set;

public class Users {

  private Set<Integer> userIds;
  private int uniqueUserCount;

  public Set<Integer> getUserIds() {
    return userIds;
  }

  public void setUserIds(Set<Integer> userIds) {
    this.userIds = userIds;
  }

  public int getUniqueUserCount() {
    return uniqueUserCount;
  }

  public void setUniqueUserCount(int uniqueUserCount) {
    this.uniqueUserCount = uniqueUserCount;
  }
}
