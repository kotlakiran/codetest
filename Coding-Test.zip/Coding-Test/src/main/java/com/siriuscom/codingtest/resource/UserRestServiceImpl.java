package com.siriuscom.codingtest.resource;


import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.siriuscom.codingtest.dto.User;
import com.siriuscom.codingtest.dto.Users;
import com.siriuscom.codingtest.service.UserService;

@Controller
public class UserRestServiceImpl implements  UserRestService {

  private static final Logger logger = LogManager.getLogger(UserRestServiceImpl.class);

  @Autowired
  private UserService userService;

  @Override
  public Users getUniqueUsers() {
    logger.debug("calling getUniqueUsers");
    return  userService.getUniqueUsers();
  }

  @Override
  public List<User> updateUsers(User user) {
    logger.debug("calling updateUsers");
    return  userService.updateUsers(user);
  }
}
