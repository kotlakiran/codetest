package com.siriuscom.codingtest.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.siriuscom.codingtest.dto.User;
import com.siriuscom.codingtest.dto.Users;
import com.siriuscom.codingtest.resource.UserRestServiceImpl;

@Service
public
class UserServiceImpl implements UserService {

  private static final Logger logger = LogManager.getLogger(UserRestServiceImpl.class);

  @Autowired
  private RestTemplate restTemplate;

  @Override
  public Users getUniqueUsers() {

   Set<Integer> uniqueUserIds =  getUser().stream().map(user -> user.getUserId()).collect(Collectors.toSet());
    Users usersData = new Users();
    usersData.setUniqueUserCount(uniqueUserIds.size());
    usersData.setUserIds(uniqueUserIds);
    logger.info("uniqueUsers ={}", usersData);
    return usersData;
  }

  @Override
  public List<User> updateUsers(User user) {
    List<User>  users = getUser();
    logger.info("Modify the 4th JSON array item, changing the title and body of the object to 1800Flowers");
    users.get(3).setTitle("1800Flowers");
    users.get(3).setBody("1800Flowers");
    logger.info("updated user List ={}", users);
    return users;
  }

  private List<User> getUser(){
    ResponseEntity<List<User>>
        users = restTemplate.exchange("http://jsonplaceholder.typicode.com/posts", HttpMethod.GET, null,
                                      new ParameterizedTypeReference<List<User>>() {});
    List<User>  usersList = users.getBody().stream().collect(Collectors.toList());
    logger.info("users list ={}", usersList);
    return usersList;
  }
}
