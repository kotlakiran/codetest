package com.siriuscom.codingtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingTestApplication {

  public static void main(String[] args) {
    SpringApplication.run(CodingTestApplication.class, args);
  }

}
