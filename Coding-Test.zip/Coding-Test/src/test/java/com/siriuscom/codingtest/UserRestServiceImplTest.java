package com.siriuscom.codingtest;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.siriuscom.codingtest.dto.User;
import com.siriuscom.codingtest.dto.Users;
import com.siriuscom.codingtest.service.UserServiceImpl;
import com.siriuscom.codingtest.resource.UserRestServiceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class UserRestServiceImplTest {

  @InjectMocks
  UserRestServiceImpl userRestServiceImpl;

  @Mock
  UserServiceImpl userService;


  @DisplayName("getUniqueUsers")
  @Test
  void testGetUniqueUsers() throws JsonProcessingException {
    Users users = new Users();
    users.setUniqueUserCount(10);
    users.setUserIds(Set.of(1,2,3,4));
    Mockito.when(userService.getUniqueUsers()).thenReturn(users);
    userRestServiceImpl.getUniqueUsers();
    assertEquals(10, users.getUniqueUserCount());
    assertEquals(users.getUserIds(), users.getUserIds());
  }

  @DisplayName("update 4th user with 1800Flowers")
  @Test
  void testUpdate4thUser() {
    List<User> users=new ArrayList<>();
    User user1=new User();
    user1.setUserId(1);
    User user4=new User();
    user4.setTitle("1800Flowers");
    user4.setBody("1800Flowers");
    users.add(user1); users.add(user1); users.add(user1);
    users.add(user4);
    Mockito.when(userService.updateUsers(Mockito.any())).thenReturn(users);
    List<User> usersList = userService.updateUsers(new User());
    assertEquals("1800Flowers", usersList.get(3).getBody());
    assertEquals("1800Flowers", usersList.get(3).getTitle());
  }


}